package com.java.mymobile.domain.dtos.veiw;

public class UserRoleViewDto {
    private String role;

    public String getRole() {
        return role;
    }

    public UserRoleViewDto setRole(String role) {
        this.role = role;
        return this;
    }
}
