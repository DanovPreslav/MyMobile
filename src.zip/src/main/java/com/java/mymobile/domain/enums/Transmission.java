package com.java.mymobile.domain.enums;

public enum Transmission { MANUAL,
    AUTOMATIC
}
