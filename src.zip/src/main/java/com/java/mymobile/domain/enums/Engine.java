package com.java.mymobile.domain.enums;

public enum Engine {
    GASOLINE,
    DIESEL,
    ELECTRIC,
    HYBRID,


}
