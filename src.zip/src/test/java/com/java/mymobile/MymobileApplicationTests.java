package com.java.mymobile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MymobileApplicationTests {

    @Test
    void contextLoads() {
    }

}
